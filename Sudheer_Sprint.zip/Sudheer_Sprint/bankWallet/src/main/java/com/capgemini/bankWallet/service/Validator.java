package com.capgemini.bankWallet.service;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bankWallet.exceptions.AccountException;
import com.capgemini.bankWallet.model.Account;


public class Validator {

	public void validator(Account user) throws AccountException
	{
		try {
			validatePhoneNumber(user.getPhoneNumber());
			validateEmail(user.getEmailId());
			
		} catch (AccountException e) {
			// TODO Auto-generated catch block
			throw new AccountException(e.getMessage());
		}
	}

	public void validateEmail(String string) throws AccountException
	{
	
			Pattern p = Pattern.compile("\\b[a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}\\b");
			Matcher m = p.matcher(string);
			if(!m.matches())
			{
				throw new AccountException("Please give a valid email");
			}
	
	}

	public void validatePhoneNumber(long phone) throws AccountException
	{
			String temp=String.valueOf(phone);
			Pattern p = Pattern.compile("\\d{10}");
			Matcher m = p.matcher(temp);
			if(!m.matches() || (!(temp.length()==10)))
			{
				throw new AccountException("Please give a valid phone number");
			}
	}
	
}
