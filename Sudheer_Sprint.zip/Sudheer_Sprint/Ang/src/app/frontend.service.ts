import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";

import { Observable } from "rxjs/internal/Observable";

@Injectable({
  providedIn: 'root'
})

@Injectable({
  providedIn: 'root'
})
export class FrontendService {
  
  constructor(private httpClient: HttpClient) {
  } 

baseUrl = 'http://localhost:5555/';

  public viewAll(): Observable<Account[]> {
    return this.httpClient.get<Account[]>('http://localhost:5555/viewall');
  }

  public create(account): Observable<Account[]>
  {
    // console.log(account);
    return this.httpClient.post<Account[]>("http://localhost:5555/create",account);
  }

  public findbyid(id): Observable<Account[]>
  {
    return this.httpClient.get<Account[]>("http://localhost:5555/viewbyid/"+id);
  }

  public findaccounts(number1,number2): Observable<Account[]> {
    return this.httpClient.get<Account[]>('http://localhost:5555/viewaccounts/'+number1+"/"+number2);
  } 

  public update(id,amount): Observable<Account[]>
  {
    return this.httpClient.put<Account[]>("http://localhost:5555/addmoney/"+id,{},{ params: {'number': amount}});
  }

  public transfer(id1,id2,amount): Observable<Account[]>
  {
    return this.httpClient.put<Account[]>("http://localhost:5555/transfer/"+id1+"/"+id2,{},{ params: {'number': amount}});
  }
}
