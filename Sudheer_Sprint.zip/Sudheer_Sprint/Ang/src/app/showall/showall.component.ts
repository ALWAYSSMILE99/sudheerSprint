import { Component, OnInit } from '@angular/core';
//import data from '../../data/details.json'
import { FrontendService } from '../frontend.service';
//import { Account } from '../Account';
@Component({
  selector: 'app-showall',
  templateUrl: './showall.component.html',
  styleUrls: ['./showall.component.css']
})
export class ShowallComponent implements OnInit {
  array:any
  //obj=Account;
  
  constructor(private service: FrontendService) {
    
   }

   
  ngOnInit() {
    this.service.viewAll().subscribe(data=>{this.array=data});
  }
  
}
