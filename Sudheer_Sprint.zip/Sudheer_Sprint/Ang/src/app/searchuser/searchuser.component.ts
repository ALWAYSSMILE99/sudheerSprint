import { Component, OnInit } from '@angular/core';
//import data from '../../data/details.json'
import { FrontendService } from '../frontend.service';


@Component({
  selector: 'app-searchuser',
  templateUrl: './searchuser.component.html',
  styleUrls: ['./searchuser.component.css']
})
export class SearchuserComponent implements OnInit {
  array=[];
  flag=false
    constructor(private service: FrontendService) { }
  
    ngOnInit() {
    }
  
    setFlag(id)
    {
      this.service.findbyid(id).subscribe(data=>{this.array=data})
      this.flag=true
    }
}

