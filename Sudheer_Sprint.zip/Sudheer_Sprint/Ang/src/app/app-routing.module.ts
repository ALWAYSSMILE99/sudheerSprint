import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CreateuserComponent } from './createuser/createuser.component';
import { SearchuserComponent } from './searchuser/searchuser.component';
import { AddbalanceComponent } from './addbalance/addbalance.component';
import { TransferComponent } from './transfer/transfer.component';
import { ShowallComponent } from './showall/showall.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'create',
    component: CreateuserComponent
  },
  {
    path: 'search',
    component: SearchuserComponent
  },
  {
    path: 'addmoney',
    component: AddbalanceComponent
  },
  {
    path: 'transfer',
    component: TransferComponent
  },
  {
    path: 'showall',
    component: ShowallComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
