drop database bank;

create database bank;
use bank;

Create table account(accountnumber int(4) auto_increment primary key,name varchar(10), phonenumber bigint(10), emailid varchar(20),balance bigint(10));

drop table account;

select * from account;
insert into account values(10,"ram",9100646436,"ram@gmail.com",1000);